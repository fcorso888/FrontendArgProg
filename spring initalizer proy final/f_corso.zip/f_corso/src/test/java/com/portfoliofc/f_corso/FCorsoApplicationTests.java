package com.portfoliofc.f_corso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FCorsoApplicationTests {

	@Test
	void contextLoads() {
	}

}
