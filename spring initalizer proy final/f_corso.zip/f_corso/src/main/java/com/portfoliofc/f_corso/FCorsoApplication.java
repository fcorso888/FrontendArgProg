package com.portfoliofc.f_corso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FCorsoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FCorsoApplication.class, args);
	}

}
